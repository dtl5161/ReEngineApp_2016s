#include "MyBoundingBoxClass.h"

MyBoundingBoxClass::MyBoundingBoxClass(std::vector<vector3> vertexList)
{
	m_bColliding = false;
	m_fRadius = 0.0f;
	m_v3CenterGlobal = vector3(0.0f);
	m_v3NewCenterGlobal = vector3(0.0f);
	m_v3NewCenterLocal = vector3(0.0f);
	m_v3NewMin = vector3(0.0f);
	m_v3NewMax = vector3(0.0f);
	m_v3NewSize = vector3(0.0f);
	m_v3NewMinG = vector3(0.0f);
	m_v3NewMaxG = vector3(0.0f);

	if (vertexList.size() < 1)
		return;

	m_v3Min = vertexList[0];
	m_v3Max = vertexList[0];

	for (int i = 1; i < vertexList.size(); i++)
	{
		if (m_v3Min.x > vertexList[i].x)
		{
			m_v3Min.x = vertexList[i].x;
		}
		else if (m_v3Max.x < vertexList[i].x)
		{
			m_v3Max.x = vertexList[i].x;
		}

		if (m_v3Min.y > vertexList[i].y)
		{
			m_v3Min.y = vertexList[i].y;
		}
		else if (m_v3Max.y < vertexList[i].y)
		{
			m_v3Max.y = vertexList[i].y;
		}

		if (m_v3Min.z > vertexList[i].z)
		{
			m_v3Min.z = vertexList[i].z;
		}
		else if (m_v3Max.z < vertexList[i].z)
		{
			m_v3Max.z = vertexList[i].z;
		}
	}

	m_v3CenterLocal = m_v3CenterGlobal = (m_v3Max + m_v3Min) / 2.0f;
	m_fRadius = glm::distance(m_v3CenterGlobal, m_v3Max);
	m_pMeshMngr = MeshManagerSingleton::GetInstance();
	m_v3Size = m_v3Max - m_v3Min;

	m_v3MinG = m_v3Min;
	m_v3MaxG = m_v3Max;
	m_v3NewCenterLocal = m_v3CenterLocal;
	
	
	m_v3Size.x = glm::distance(vector3(m_v3Min.x, 0.0, 0.0), vector3(m_v3Max.x, 0.0, 0.0));
	m_v3Size.y = glm::distance(vector3(0.0, m_v3Min.y, 0.0), vector3(0.0, m_v3Max.y, 0.0));
	m_v3Size.z = glm::distance(vector3(0.0, 0.0, m_v3Min.z), vector3(0.0, 0.0, m_v3Max.z));

	m_v3NewSize = m_v3Size;
}

void MyBoundingBoxClass::RenderBox()
{
	vector3 v3Color = REGREEN;
	if (true == m_bColliding)
		v3Color = RERED;

	m_pMeshMngr->AddCubeToRenderList(
		m_m4ToWorld * 
		glm::translate(m_v3CenterLocal) *
		glm::scale(m_v3Size),
		v3Color, WIRE);

	m_pMeshMngr->AddCubeToRenderList(
		m_m4ToNewWorld * glm::inverse(ToMatrix4(tempRot)) *
		glm::translate(m_v3NewCenterLocal) *
		glm::scale(m_v3NewSize),
		v3Color, WIRE);
	//std::cout << m_m4ToNewWorld;
	std::cout << m_v3CenterLocal.x << std::endl;
	std::cout << m_v3NewCenterLocal.x << std::endl;
}

void MyBoundingBoxClass::SetOrthoBox(quaternion quat)
{
	vector3 maxXmaxYmaxZ = vector3(m_v3Max.x, m_v3Max.y, m_v3Max.z);
	vector3 minXmaxYmaxZ = vector3(m_v3Min.x, m_v3Max.y, m_v3Max.z);
	vector3 minXminYmaxZ = vector3(m_v3Min.x, m_v3Min.y, m_v3Max.z);
	vector3 minXminYminZ = vector3(m_v3Min.x, m_v3Min.y, m_v3Min.z);
	vector3 maxXminYminZ = vector3(m_v3Max.x, m_v3Min.y, m_v3Min.z);
	vector3 maxXmaxYminZ = vector3(m_v3Max.x, m_v3Max.y, m_v3Min.z);
	vector3 maxXminYmaxZ = vector3(m_v3Max.x, m_v3Min.y, m_v3Max.z);
	vector3 minXmaxYminZ = vector3(m_v3Min.x, m_v3Max.y, m_v3Min.z);
	std::vector<vector3> newMinMaxs = { maxXmaxYmaxZ, minXmaxYmaxZ, minXminYmaxZ, minXminYminZ, maxXminYminZ, maxXmaxYminZ, maxXminYmaxZ, minXmaxYminZ };

	m_v3NewMax = vector3(ToMatrix4(quat) * vector4(newMinMaxs[0],1.0f));
	m_v3NewMin = vector3(ToMatrix4(quat) * vector4(newMinMaxs[0], 1.0f));

	for (int i = 1; i < newMinMaxs.size(); i++)
	{
		vector3 myVector = vector3(ToMatrix4(quat) * vector4(newMinMaxs[i], 1.0f));
		if (m_v3NewMin.x > myVector.x)
		{
			m_v3NewMin.x = myVector.x;
		}
		else if (m_v3NewMax.x < myVector.x)
		{
			m_v3NewMax.x = myVector.x;
		}

		if (m_v3NewMin.y > myVector.y)
		{
			m_v3NewMin.y = myVector.y;
		}
		else if (m_v3NewMax.y < myVector.y)
		{
			m_v3NewMax.y = myVector.y;
		}

		if (m_v3NewMin.z > myVector.z)
		{
			m_v3NewMin.z = myVector.z;
		}
		else if (m_v3NewMax.z < myVector.z)
		{
			m_v3NewMax.z = myVector.z;
		}
	}

	m_v3NewCenterLocal = (m_v3NewMax + m_v3NewMin)/2.0f;

	m_v3NewSize.x = glm::distance(vector3(m_v3NewMin.x, 0.0, 0.0), vector3(m_v3NewMax.x, 0.0, 0.0));
	m_v3NewSize.y = glm::distance(vector3(0.0, m_v3NewMin.y, 0.0), vector3(0.0, m_v3NewMax.y, 0.0));
	m_v3NewSize.z = glm::distance(vector3(0.0, 0.0, m_v3NewMin.z), vector3(0.0, 0.0, m_v3NewMax.z));
	tempRot = quat;
	/*
	vector3 v3Color = REGREEN;
	if (true == m_bColliding)
		v3Color = RERED;

	m_pMeshMngr->AddCubeToRenderList(
		m_m4ToWorld * glm::inverse(ToMatrix4(tempRot)) *
		glm::translate(m_v3NewCenterLocal) *
		glm::scale(m_v3Size),
		v3Color, WIRE);*/
}
void MyBoundingBoxClass::SetModelMatrix(matrix4 a_m4ToWorld)
{
	if (m_m4ToWorld == a_m4ToWorld)
		return;

	m_m4ToWorld = a_m4ToWorld;
	m_v3CenterGlobal = vector3(m_m4ToWorld * vector4(m_v3CenterLocal, 1.0f));
	m_v3MinG = vector3(m_m4ToWorld * vector4(m_v3Min, 1.0f));
	m_v3MaxG = vector3(m_m4ToWorld * vector4(m_v3Max, 1.0f));

	m_m4ToNewWorld = a_m4ToWorld;
	m_v3NewCenterGlobal = vector3(m_m4ToNewWorld * vector4(m_v3NewCenterLocal, 1.0f));
	m_v3NewMinG = vector3(m_m4ToNewWorld * vector4(m_v3NewMin, 1.0f));
	m_v3NewMaxG = vector3(m_m4ToNewWorld * vector4(m_v3NewMax, 1.0f));
}

bool MyBoundingBoxClass::IsColliding(MyBoundingBoxClass* a_other)
{
	if (this->m_v3MaxG.x < a_other->m_v3MinG.x)
		return false;
	if (this->m_v3MinG.x > a_other->m_v3MaxG.x)
		return false;

	if (this->m_v3MaxG.y < a_other->m_v3MinG.y)
		return false;
	if (this->m_v3MinG.y > a_other->m_v3MaxG.y)
		return false;

	if (this->m_v3MaxG.z < a_other->m_v3MinG.z)
		return false;
	if (this->m_v3MinG.z > a_other->m_v3MaxG.z)
		return false;

	return true;
}

void MyBoundingBoxClass::SetColliding(bool input) { m_bColliding = input; }
void MyBoundingBoxClass::SetCenterLocal(vector3 input) { m_v3CenterLocal = input; }
void MyBoundingBoxClass::SetCenterGlobal(vector3 input) { m_v3CenterGlobal = input; }
void MyBoundingBoxClass::SetRadius(float input) { m_fRadius = input; }
bool MyBoundingBoxClass::GetColliding(void) { return m_bColliding; }
vector3 MyBoundingBoxClass::GetCenterLocal(void) { return m_v3CenterLocal; }
vector3 MyBoundingBoxClass::GetCenterGlobal(void) { return m_v3CenterGlobal; }
float MyBoundingBoxClass::GetRadius(void) { return m_fRadius; }
matrix4 MyBoundingBoxClass::GetModelMatrix(void) { return m_m4ToWorld; }